jQuery(document).ready(function($){
    $('.wp-color-picker-field').wpColorPicker();
});